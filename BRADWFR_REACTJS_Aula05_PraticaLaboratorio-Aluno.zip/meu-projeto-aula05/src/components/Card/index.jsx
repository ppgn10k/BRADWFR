import styles from './styles.module.css';

export function Card({ title, imageSrc, stockQuantity, children }) {
  return (
    <div className={styles.cardContainer}>
      <div className={styles.imageContainer}>
        <img src={imageSrc} alt={title} className={styles.bookImage} />
      </div>
      <div className={styles.infoContainer}>
        <h2 className={styles.title}>{title}</h2>
        {children}
        <p className={styles.stock}>Quantidade de exemplares: {stockQuantity} unidades.</p>
        <button className={styles.button}>Comprar agora</button>
      </div>
    </div>
  );
}
