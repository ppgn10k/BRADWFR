import { Card } from './components/Card';
import habitoImg from './assets/habito.jpg';
import mindsetImg from './assets/mindset.jpg';
import persuasaoImg from './assets/persuasao.jpg';

function App() {
  const containerStyle = {
    backgroundColor: '#d0dae4',
    padding: '40px 20px',
    minHeight: '100vh',
    textAlign: 'center'
  };

  return (
    <div style={containerStyle}>
      
      <Card 
        title="Book O Poder do Hábito" 
        imageSrc={habitoImg} 
        stockQuantity={10}
      >
        <p style={{ color: '#444', lineHeight: '1.5', margin: 0 }}>
          Durante os últimos dois anos, uma jovem transformou quase todos os aspectos de sua vida. 
          Parou de fumar, correu uma maratona e foi promovida. Em um laboratório, neurologistas 
          descobriram que os padrões dentro do cérebro dela mudaram de maneira fundamental.
        </p>
      </Card>

      <Card 
        title="Book Mindset: A nova psicologia do sucesso" 
        imageSrc={mindsetImg} 
        stockQuantity={5}
      >
        <p style={{ color: '#444', lineHeight: '1.5', margin: 0 }}>
          Dweck revela de forma brilhante como o sucesso pode ser alcançado pela maneira como 
          lidamos com nossos objetivos.
        </p>
      </Card>

      <Card 
        title="Book As armas da persuasão: Como influenciar e não se deixar influenciar" 
        imageSrc={persuasaoImg} 
        stockQuantity={8}
      >
        <p style={{ color: '#444', lineHeight: '1.5', margin: 0 }}>
          Depois de passar anos caindo na lábia de vendedores, arrecadadores de doações e 
          operadores de telemarketing, o psicólogo Robert B. Cialdini resolveu se dedicar ao estudo da persuasão.
        </p>
      </Card>

    </div>
  );
}

export default App;
